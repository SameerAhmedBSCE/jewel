import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Eternal Diamond Band',
    price: 125000,
    category: 'Rings',
    image: 'https://picsum.photos/seed/diamond-ring/800/800',
    description: 'A timeless symbol of commitment, crafted in 18k white gold with brilliant-cut diamonds.',
    materials: ['18k White Gold', 'Diamonds'],
    isBestSeller: true,
  },
  {
    id: '2',
    name: 'Sapphire Night Pendant',
    price: 85000,
    category: 'Necklaces',
    image: 'https://picsum.photos/seed/sapphire-necklace/800/800',
    description: 'Deep blue sapphire surrounded by a halo of shimmering diamonds on a delicate gold chain.',
    materials: ['14k Yellow Gold', 'Sapphire', 'Diamonds'],
    isBestSeller: true,
  },
  {
    id: '3',
    name: 'Royal Emerald Studs',
    price: 65000,
    category: 'Earrings',
    image: 'https://picsum.photos/seed/emerald-earrings/800/800',
    description: 'Exquisite emerald studs that capture the essence of luxury and natural beauty.',
    materials: ['18k Yellow Gold', 'Emeralds'],
    isBestSeller: true,
  },
  {
    id: '4',
    name: 'Golden Link Bracelet',
    price: 45000,
    category: 'Bracelets',
    image: 'https://picsum.photos/seed/gold-bracelet/800/800',
    description: 'A sophisticated link bracelet that adds a touch of gold to any ensemble.',
    materials: ['14k Yellow Gold'],
    isBestSeller: true,
  },
  {
    id: '5',
    name: 'Pearl Essence Necklace',
    price: 55000,
    category: 'Necklaces',
    image: 'https://picsum.photos/seed/pearl-necklace/800/800',
    description: 'Lustrous freshwater pearls hand-knotted on a silk thread with a gold clasp.',
    materials: ['Freshwater Pearls', '14k Yellow Gold'],
  },
  {
    id: '6',
    name: 'Celestial Star Ring',
    price: 32000,
    category: 'Rings',
    image: 'https://picsum.photos/seed/star-ring/800/800',
    description: 'A delicate ring featuring a star motif adorned with tiny sparkling crystals.',
    materials: ['Sterling Silver', 'Cubic Zirconia'],
  },
  // Adding more to reach 30 with stable IDs
  ...Array.from({ length: 24 }).map((_, i) => {
    return {
      id: (i + 7).toString(),
      name: `${['Diamond', 'Gold', 'Silver', 'Ruby', 'Emerald', 'Sapphire'][i % 6]} ${['Elegance', 'Grace', 'Majesty', 'Radiance', 'Charm'][i % 5]} ${['Ring', 'Necklace', 'Earrings', 'Bracelet'][i % 4]}`,
      price: 25000 + (Math.random() * 150000),
      category: ['Rings', 'Necklaces', 'Earrings', 'Bracelets'][i % 4] as any,
      image: `https://picsum.photos/seed/product-${i}/800/1000`,
      description: 'A masterpiece of craftsmanship, designed for the modern woman who appreciates timeless luxury.',
      materials: ['Gold', 'Diamonds'],
      isBestSeller: i < 2,
    };
  })
];

export const BRAND_NAME = "Luvérin Jewels";
