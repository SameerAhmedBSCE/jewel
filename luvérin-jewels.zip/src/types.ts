export interface Product {
  id: string;
  name: string;
  price: number;
  category: 'Rings' | 'Necklaces' | 'Earrings' | 'Bracelets';
  image: string;
  description: string;
  materials: string[];
  isBestSeller?: boolean;
}

export type Page = 'home' | 'shop' | 'about' | 'contact' | 'product';
