import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingBag, 
  Search, 
  Menu, 
  X, 
  ChevronRight, 
  Star, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Gift,
  Instagram,
  Facebook,
  Twitter,
  ArrowRight,
  MapPin,
  Phone,
  Mail,
  Heart,
  Plus,
  Minus
} from 'lucide-react';
import { Product, Page } from './types';
import { PRODUCTS, BRAND_NAME } from './constants';

// --- Components ---

const Logo = ({ isScrolled, hasHero, light }: { isScrolled?: boolean, hasHero?: boolean, light?: boolean }) => {
  const isDarkText = !light && (isScrolled || !hasHero);
  return (
    <div className={`flex flex-col items-center justify-center transition-all duration-500 ${isScrolled ? 'scale-90' : 'scale-100'}`}>
      <span className={`font-serif text-xl md:text-2xl tracking-[0.2em] uppercase font-bold text-center transition-colors duration-500 ${
        isDarkText ? 'text-luxury-blue' : 'text-white'
      }`}>
        Luvérin
      </span>
      <span className="text-[7px] md:text-[8px] uppercase tracking-[0.5em] -mt-1 text-center text-luxury-gold">
        Jewels
      </span>
    </div>
  );
};

const Navbar = ({ 
  currentPage, 
  setPage, 
  cartCount 
}: { 
  currentPage: Page, 
  setPage: (p: Page) => void,
  cartCount: number
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Pages that have a dark hero banner at the top
  const hasHero = ['home', 'shop', 'about', 'contact', 'product'].includes(currentPage);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks: { label: string, page: Page }[] = [
    { label: 'Home', page: 'home' },
    { label: 'Shop', page: 'shop' },
    { label: 'About', page: 'about' },
    { label: 'Contact', page: 'contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-700 ${
      isScrolled 
        ? 'bg-white/95 backdrop-blur-md py-6 shadow-lg' 
        : hasHero 
          ? 'bg-transparent py-8' 
          : 'bg-white py-6 shadow-sm'
    }`}>
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-3 items-center">
        {/* Left: Navigation Links - Desktop & Mobile Menu Toggle */}
        <div className="flex items-center">
          <button 
            className={`lg:hidden ${isScrolled || !hasHero ? 'text-luxury-blue' : 'text-white'}`}
            onClick={() => setIsMobileMenuOpen(true)}
          >
            <Menu size={24} />
          </button>
          <div className="hidden lg:flex items-center space-x-10">
            {navLinks.map((link) => (
              <button
                key={link.page}
                onClick={() => setPage(link.page)}
                className={`text-[10px] uppercase tracking-[0.3em] font-bold transition-all duration-300 hover:text-luxury-gold relative group ${
                  currentPage === link.page 
                    ? 'text-luxury-gold' 
                    : (isScrolled || !hasHero) ? 'text-luxury-blue' : 'text-white'
                }`}
              >
                {link.label}
                <span className={`absolute -bottom-2 left-0 w-0 h-[1px] bg-luxury-gold transition-all duration-300 group-hover:w-full ${currentPage === link.page ? 'w-full' : ''}`} />
              </button>
            ))}
          </div>
        </div>

        {/* Center: Logo */}
        <div className="flex justify-center">
          <button onClick={() => setPage('home')} className="flex items-center">
            <Logo isScrolled={isScrolled} hasHero={hasHero} />
          </button>
        </div>

        {/* Right: Icons */}
        <div className={`flex justify-end items-center space-x-8 ${isScrolled || !hasHero ? 'text-luxury-blue' : 'text-white'}`}>
          <button className="hover:text-luxury-gold transition-all duration-300">
            <Search size={20} />
          </button>
          <button className="hover:text-luxury-gold transition-all duration-300 relative" onClick={() => setPage('shop')}>
            <ShoppingBag size={20} />
            {cartCount > 0 && (
              <motion.span 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-2 -right-2 bg-luxury-gold text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow-lg"
              >
                {cartCount}
              </motion.span>
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 bg-luxury-blue z-[60] flex flex-col p-10"
          >
            <button 
              className="self-end text-white mb-12"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              <X size={32} />
            </button>
            <div className="flex flex-col space-y-8">
              {navLinks.map((link) => (
                <button
                  key={link.page}
                  onClick={() => {
                    setPage(link.page);
                    setIsMobileMenuOpen(false);
                  }}
                  className="text-white text-3xl font-serif tracking-wide text-left hover:text-luxury-gold transition-colors"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Footer = ({ setPage }: { setPage: (p: Page) => void }) => {
  return (
    <footer className="bg-deep-navy text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
        {/* Brand Info */}
        <div className="space-y-6">
          <Logo light />
          <p className="text-white/60 text-sm leading-relaxed">
            Modern luxury jewelry house from Pakistan, focused on timeless craftsmanship and the celebration of elegance.
          </p>
          <div className="flex space-x-4">
            <Instagram className="text-white/60 hover:text-luxury-gold cursor-pointer transition-colors" size={20} />
            <Facebook className="text-white/60 hover:text-luxury-gold cursor-pointer transition-colors" size={20} />
            <Twitter className="text-white/60 hover:text-luxury-gold cursor-pointer transition-colors" size={20} />
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="font-serif text-xl mb-6">Quick Links</h4>
          <ul className="space-y-4 text-sm text-white/60">
            <li><button onClick={() => setPage('home')} className="hover:text-luxury-gold transition-colors">Home</button></li>
            <li><button onClick={() => setPage('shop')} className="hover:text-luxury-gold transition-colors">Shop All</button></li>
            <li><button onClick={() => setPage('about')} className="hover:text-luxury-gold transition-colors">Our Story</button></li>
            <li><button onClick={() => setPage('contact')} className="hover:text-luxury-gold transition-colors">Contact Us</button></li>
          </ul>
        </div>

        {/* Categories */}
        <div>
          <h4 className="font-serif text-xl mb-6">Collections</h4>
          <ul className="space-y-4 text-sm text-white/60">
            <li><button onClick={() => setPage('shop')} className="hover:text-luxury-gold transition-colors">Rings</button></li>
            <li><button onClick={() => setPage('shop')} className="hover:text-luxury-gold transition-colors">Necklaces</button></li>
            <li><button onClick={() => setPage('shop')} className="hover:text-luxury-gold transition-colors">Earrings</button></li>
            <li><button onClick={() => setPage('shop')} className="hover:text-luxury-gold transition-colors">Bracelets</button></li>
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="font-serif text-xl mb-6">Contact Us</h4>
          <ul className="space-y-4 text-sm text-white/60">
            <li className="flex items-start space-x-3">
              <MapPin size={18} className="text-luxury-gold shrink-0" />
              <span>Gulberg III, Lahore, Pakistan</span>
            </li>
            <li className="flex items-center space-x-3">
              <Phone size={18} className="text-luxury-gold shrink-0" />
              <span>+92 300 1234567</span>
            </li>
            <li className="flex items-center space-x-3">
              <Mail size={18} className="text-luxury-gold shrink-0" />
              <span>concierge@luverin.pk</span>
            </li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 pt-10 border-t border-white/10 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0 text-[10px] uppercase tracking-[0.2em] text-white/40">
        <p>© 2024 Luvérin Jewels. All Rights Reserved.</p>
        <div className="flex space-x-6">
          <button className="hover:text-white transition-colors">Privacy Policy</button>
          <button className="hover:text-white transition-colors">Terms of Service</button>
          <button className="hover:text-white transition-colors">Shipping Policy</button>
        </div>
      </div>
    </footer>
  );
};

const ProductCard = ({ product, onClick, onAddToCart }: { product: Product, onClick: () => void, onAddToCart: (e: React.MouseEvent<Element, MouseEvent>) => void, key?: string }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group cursor-pointer"
      onClick={onClick}
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-champagne mb-4">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-luxury-blue/0 group-hover:bg-luxury-blue/10 transition-colors duration-500" />
        
        {/* Quick Actions */}
        <div className="absolute bottom-0 left-0 w-full p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-500 flex space-x-2">
          <button 
            onClick={onAddToCart}
            className="flex-1 bg-white text-luxury-blue py-3 text-[10px] uppercase tracking-widest font-bold hover:bg-luxury-gold hover:text-white transition-colors shadow-xl"
          >
            Add to Cart
          </button>
          <button className="bg-white text-luxury-blue p-3 hover:bg-luxury-gold hover:text-white transition-colors shadow-xl">
            <Heart size={16} />
          </button>
        </div>
        
        {product.isBestSeller && (
          <span className="absolute top-4 left-4 bg-luxury-gold text-white text-[10px] uppercase tracking-widest px-3 py-1 font-bold">
            Best Seller
          </span>
        )}
      </div>
      <div className="text-center">
        <h3 className="font-serif text-lg mb-1 group-hover:text-luxury-gold transition-colors">{product.name}</h3>
        <p className="text-luxury-blue/60 text-sm font-medium">Rs. {product.price.toLocaleString()}</p>
      </div>
    </motion.div>
  );
};

const PageBanner = ({ title, subtitle, image }: { title: string, subtitle?: string, image: string }) => (
  <section className="relative h-[60vh] flex items-center justify-center overflow-hidden">
    <div className="absolute inset-0 z-0">
      <img 
        src={image} 
        alt={title}
        className="w-full h-full object-cover"
        referrerPolicy="no-referrer"
      />
      <div className="absolute inset-0 bg-luxury-blue/50" />
    </div>
    <div className="relative z-10 text-center text-white px-6">
      <motion.h1 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-5xl md:text-7xl font-serif mb-6"
      >
        {title}
      </motion.h1>
      {subtitle && (
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto font-light tracking-wide"
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  </section>
);

const SignatureExperience = () => (
  <section className="py-32 px-6 bg-white overflow-hidden">
    <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="relative group"
      >
        <div className="aspect-[4/5] overflow-hidden">
          <img 
            src="https://picsum.photos/seed/signature-experience/800/1000" 
            alt="Signature Experience"
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="absolute -top-10 -left-10 w-40 h-40 border border-luxury-gold/30 hidden lg:block" />
        <div className="absolute -bottom-10 -right-10 w-40 h-40 border border-luxury-gold/30 hidden lg:block" />
      </motion.div>
      <div className="space-y-10">
        <span className="text-luxury-gold uppercase tracking-[0.4em] text-[10px] font-bold block">The Signature Experience</span>
        <h2 className="text-4xl md:text-6xl font-serif leading-tight">Elevating Every <br /> Precious Moment</h2>
        <p className="text-luxury-blue/70 text-lg leading-relaxed font-light">
          At Luvérin, we believe that luxury is not just about the product, but the journey. From the moment you enter our world, you are treated to a bespoke experience tailored to your unique desires.
        </p>
        <div className="grid grid-cols-2 gap-8">
          <div>
            <h4 className="font-serif text-2xl mb-2">Private Viewing</h4>
            <p className="text-sm text-luxury-blue/60">One-on-one consultations with our expert gemologists.</p>
          </div>
          <div>
            <h4 className="font-serif text-2xl mb-2">Bespoke Design</h4>
            <p className="text-sm text-luxury-blue/60">Bring your vision to life with our custom design services.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const BespokeCreations = () => (
  <section className="py-32 bg-deep-navy text-white overflow-hidden relative">
    <div className="absolute top-0 right-0 w-1/3 h-full bg-luxury-gold/5 skew-x-12 translate-x-1/2" />
    <div className="max-w-7xl mx-auto px-6 relative z-10">
      <div className="text-center max-w-3xl mx-auto mb-20">
        <span className="text-luxury-gold uppercase tracking-[0.4em] text-[10px] font-bold mb-6 block">Custom Artistry</span>
        <h2 className="text-4xl md:text-6xl font-serif mb-8">Bespoke Creations</h2>
        <p className="text-white/60 font-light text-lg">
          Your story is unique. Your jewelry should be too. Collaborate with our master artisans to create a one-of-a-kind masterpiece that reflects your personal legacy.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
        {[
          { step: '01', title: 'Consultation', desc: 'Share your inspiration and preferences with our design team.' },
          { step: '02', title: 'Curation', desc: 'We source the perfect stones and materials for your vision.' },
          { step: '03', title: 'Creation', desc: 'Master artisans hand-forge your piece with meticulous precision.' }
        ].map((item, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.2 }}
            className="p-10 border border-white/10 hover:border-luxury-gold transition-colors duration-500 group"
          >
            <span className="text-4xl font-serif text-luxury-gold/30 group-hover:text-luxury-gold transition-colors mb-6 block">{item.step}</span>
            <h3 className="text-2xl font-serif mb-4">{item.title}</h3>
            <p className="text-white/50 text-sm leading-relaxed">{item.desc}</p>
          </motion.div>
        ))}
      </div>
      <div className="mt-20 text-center">
        <button className="px-12 py-5 border border-luxury-gold text-luxury-gold uppercase tracking-widest text-xs font-bold hover:bg-luxury-gold hover:text-white transition-all duration-500">
          Start Your Bespoke Journey
        </button>
      </div>
    </div>
  </section>
);

// --- New Sections ---

const GiftingSuite = () => {
  return (
    <section className="py-32 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <span className="text-luxury-gold uppercase tracking-[0.4em] text-[10px] font-bold mb-4 block">The Art of Giving</span>
          <h2 className="text-4xl md:text-6xl font-serif">The Gifting Suite</h2>
          <div className="w-24 h-[1px] bg-luxury-gold mx-auto mt-8" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 h-auto md:h-[800px]">
          {/* Main Feature */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="md:col-span-7 relative group overflow-hidden"
          >
            <img 
              src="https://picsum.photos/seed/gift-main/1200/1400" 
              alt="Wedding Gifts" 
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-luxury-blue/80 via-transparent to-transparent opacity-60 group-hover:opacity-80 transition-opacity" />
            <div className="absolute bottom-12 left-12 text-white">
              <span className="text-[10px] uppercase tracking-[0.3em] font-bold mb-4 block">Eternal Vows</span>
              <h3 className="text-4xl font-serif mb-6">Wedding Collection</h3>
              <button className="px-8 py-3 border border-white/40 text-white uppercase tracking-widest text-[10px] font-bold hover:bg-white hover:text-luxury-blue transition-all">
                Discover More
              </button>
            </div>
          </motion.div>

          {/* Side Stack */}
          <div className="md:col-span-5 flex flex-col gap-6">
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex-1 relative group overflow-hidden"
            >
              <img 
                src="https://picsum.photos/seed/gift-anniversary/800/600" 
                alt="Anniversary Gifts" 
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-luxury-blue/30 group-hover:bg-luxury-blue/50 transition-colors" />
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                <span className="text-[10px] uppercase tracking-[0.3em] font-bold mb-2">Milestones</span>
                <h3 className="text-2xl font-serif">Anniversary Gifts</h3>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="flex-1 relative group overflow-hidden"
            >
              <img 
                src="https://picsum.photos/seed/gift-bespoke/800/600" 
                alt="Bespoke Gifts" 
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-luxury-blue/30 group-hover:bg-luxury-blue/50 transition-colors" />
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                <span className="text-[10px] uppercase tracking-[0.3em] font-bold mb-2">Personalized</span>
                <h3 className="text-2xl font-serif">Bespoke Creations</h3>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ArtisanalHeritage = () => {
  return (
    <section className="relative py-40 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/seed/heritage-bg/1920/1080" 
          alt="Heritage Background" 
          className="w-full h-full object-cover opacity-20"
          referrerPolicy="no-referrer"
        />
      </div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          <div className="order-2 lg:order-1">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="aspect-square bg-champagne overflow-hidden rounded-full p-12 border border-luxury-gold/20">
                <img 
                  src="https://picsum.photos/seed/artisan-hands/800/800" 
                  alt="Artisan Hands" 
                  className="w-full h-full object-cover rounded-full shadow-2xl"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -top-10 -right-10 w-48 h-48 bg-white p-6 rounded-full shadow-xl flex items-center justify-center text-center">
                <div>
                  <span className="block text-3xl font-serif text-luxury-gold">25+</span>
                  <span className="text-[8px] uppercase tracking-widest font-bold text-luxury-blue/60">Years of Mastery</span>
                </div>
              </div>
            </motion.div>
          </div>

          <div className="order-1 lg:order-2 space-y-10">
            <div className="space-y-4">
              <span className="text-luxury-gold uppercase tracking-[0.4em] text-[10px] font-bold block">The Artisanal Process</span>
              <h2 className="text-4xl md:text-6xl font-serif leading-tight text-luxury-blue">Where Tradition Meets <br /> Modern Brilliance</h2>
            </div>
            
            <div className="space-y-8">
              <div className="flex gap-6">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-champagne flex items-center justify-center text-luxury-gold font-serif text-xl italic">01</div>
                <div>
                  <h4 className="font-serif text-xl mb-2">Ethical Sourcing</h4>
                  <p className="text-luxury-blue/60 text-sm leading-relaxed">We personally select every gemstone, ensuring it meets our rigorous standards for quality and ethical origin.</p>
                </div>
              </div>
              <div className="flex gap-6">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-champagne flex items-center justify-center text-luxury-gold font-serif text-xl italic">02</div>
                <div>
                  <h4 className="font-serif text-xl mb-2">Master Benchwork</h4>
                  <p className="text-luxury-blue/60 text-sm leading-relaxed">Our master jewelers spend hundreds of hours on a single piece, perfecting every facet and setting by hand.</p>
                </div>
              </div>
              <div className="flex gap-6">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-champagne flex items-center justify-center text-luxury-gold font-serif text-xl italic">03</div>
                <div>
                  <h4 className="font-serif text-xl mb-2">Final Polishing</h4>
                  <p className="text-luxury-blue/60 text-sm leading-relaxed">A multi-stage polishing process ensures a mirror-like finish that captures and reflects light brilliantly.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ProductPromise = () => {
  return (
    <section className="py-24 bg-champagne/20 border-y border-luxury-gold/10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
          <div className="text-center space-y-6">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto shadow-sm">
              <ShieldCheck className="text-luxury-gold" size={28} />
            </div>
            <h3 className="text-xl font-serif">Lifetime Warranty</h3>
            <p className="text-luxury-blue/60 text-sm leading-relaxed">We stand by our craftsmanship. Every Luvérin piece comes with a lifetime warranty against manufacturing defects.</p>
          </div>
          <div className="text-center space-y-6">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto shadow-sm">
              <Star className="text-luxury-gold" size={28} />
            </div>
            <h3 className="text-xl font-serif">Complimentary Care</h3>
            <p className="text-luxury-blue/60 text-sm leading-relaxed">Enjoy annual professional cleaning and stone inspection at our studio to keep your jewelry in pristine condition.</p>
          </div>
          <div className="text-center space-y-6">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto shadow-sm">
              <Gift className="text-luxury-gold" size={28} />
            </div>
            <h3 className="text-xl font-serif">Bespoke Packaging</h3>
            <p className="text-luxury-blue/60 text-sm leading-relaxed">Each piece is presented in our signature velvet-lined box, accompanied by a certificate of authenticity.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

const StylingGuide = () => {
  return (
    <section className="py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div className="space-y-12">
            <div>
              <span className="text-luxury-gold uppercase tracking-[0.4em] text-[10px] font-bold mb-4 block">Inspiration</span>
              <h2 className="text-4xl md:text-5xl font-serif">The Styling Guide</h2>
              <p className="text-luxury-blue/60 mt-6 text-lg font-light leading-relaxed">
                Elevate your look with our curated styling suggestions. Whether it's a gala evening or a sophisticated day at the office, Luvérin Jewels adds the perfect touch of brilliance.
              </p>
            </div>

            <div className="space-y-8">
              <div className="border-l-2 border-luxury-gold pl-8 py-2">
                <h4 className="font-serif text-xl mb-2">Daytime Sophistication</h4>
                <p className="text-luxury-blue/60 text-sm">Pair with a crisp white silk blouse and tailored trousers for an understated yet powerful presence.</p>
              </div>
              <div className="border-l-2 border-luxury-gold/30 pl-8 py-2">
                <h4 className="font-serif text-xl mb-2">Evening Radiance</h4>
                <p className="text-luxury-blue/60 text-sm">Let this piece be the focal point against a deep velvet or satin gown. Minimalist accessories will highlight its brilliance.</p>
              </div>
              <div className="border-l-2 border-luxury-gold/30 pl-8 py-2">
                <h4 className="font-serif text-xl mb-2">The Layered Look</h4>
                <p className="text-luxury-blue/60 text-sm">Combine with delicate chains from our Essentials collection for a modern, textured aesthetic.</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-6">
              <div className="aspect-[3/4] overflow-hidden">
                <img src="https://picsum.photos/seed/style-1/600/800" alt="Style 1" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div className="aspect-square overflow-hidden">
                <img src="https://picsum.photos/seed/style-2/600/600" alt="Style 2" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
            </div>
            <div className="space-y-6 pt-12">
              <div className="aspect-square overflow-hidden">
                <img src="https://picsum.photos/seed/style-3/600/600" alt="Style 3" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div className="aspect-[3/4] overflow-hidden">
                <img src="https://picsum.photos/seed/style-4/600/800" alt="Style 4" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

// --- Pages ---


const HomePage = ({ setPage, setSelectedProduct, addToCart }: { setPage: (p: Page) => void, setSelectedProduct: (p: Product) => void, addToCart: (p: Product) => void }) => {
  const bestSellers = PRODUCTS.filter(p => p.isBestSeller).slice(0, 6);
  
  return (
    <div className="pt-0">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/seed/luxury-jewelry/1920/1080" 
            alt="Luxury Jewelry"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-luxury-blue/40" />
        </div>
        
        <div className="relative z-10 text-center text-white px-6 max-w-4xl">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-5xl md:text-7xl lg:text-8xl font-serif mb-8 leading-tight"
          >
            Timeless Luxury <br /> Crafted for You
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="text-lg md:text-xl text-white/80 mb-12 max-w-2xl mx-auto font-light leading-relaxed"
          >
            Discover handcrafted jewelry designed to elevate elegance and celebrate timeless beauty.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6"
          >
            <button 
              onClick={() => setPage('shop')}
              className="px-10 py-5 bg-luxury-gold text-white uppercase tracking-widest text-xs font-bold hover:bg-white hover:text-luxury-blue transition-all duration-500 w-full sm:w-auto"
            >
              Shop Collection
            </button>
            <button 
              onClick={() => setPage('shop')}
              className="px-10 py-5 border border-white text-white uppercase tracking-widest text-xs font-bold hover:bg-white hover:text-luxury-blue transition-all duration-500 w-full sm:w-auto"
            >
              Explore Best Sellers
            </button>
          </motion.div>
        </div>

        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/40"
        >
          <div className="w-[1px] h-16 bg-white/20 mx-auto" />
        </motion.div>
      </section>

      <SignatureExperience />

      {/* Featured Collections */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-luxury-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-4 block">Curated Selection</span>
          <h2 className="text-4xl md:text-5xl font-serif">Featured Collections</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {['Rings', 'Necklaces', 'Earrings', 'Bracelets'].map((cat, i) => (
            <motion.div 
              key={cat}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group relative aspect-[3/4] overflow-hidden cursor-pointer"
              onClick={() => setPage('shop')}
            >
              <img 
                src={[
                  'https://picsum.photos/seed/rings/800/1000',
                  'https://picsum.photos/seed/necklaces/800/1000',
                  'https://picsum.photos/seed/earrings/800/1000',
                  'https://picsum.photos/seed/bracelets/800/1000'
                ][i]} 
                alt={cat}
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-luxury-blue/20 group-hover:bg-luxury-blue/40 transition-colors duration-500" />
              <div className="absolute inset-0 flex flex-col items-center justify-center text-white">
                <h3 className="text-3xl font-serif mb-4">{cat}</h3>
                <span className="text-[10px] uppercase tracking-[0.3em] font-bold border-b border-white/40 pb-1 group-hover:border-luxury-gold transition-colors">Explore</span>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <GiftingSuite />

      {/* Best Sellers */}
      <section className="py-24 bg-champagne/30 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 space-y-4 md:space-y-0">
            <div>
              <span className="text-luxury-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-4 block">Most Loved</span>
              <h2 className="text-4xl md:text-5xl font-serif">Best Sellers</h2>
            </div>
            <button 
              onClick={() => setPage('shop')}
              className="text-luxury-blue uppercase tracking-widest text-[10px] font-bold border-b border-luxury-blue pb-1 hover:text-luxury-gold hover:border-luxury-gold transition-colors"
            >
              View All Products
            </button>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
            {bestSellers.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onClick={() => {
                  setSelectedProduct(product);
                  setPage('product');
                }}
                onAddToCart={(e) => {
                  e.stopPropagation();
                  addToCart(product);
                }}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Brand Story */}
      <section className="py-32 px-6 overflow-hidden">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-[4/5] overflow-hidden">
              <img 
                src="https://picsum.photos/seed/craftsmanship/800/1000" 
                alt="Craftsmanship"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-10 -right-10 w-64 h-80 hidden md:block border-8 border-white shadow-2xl overflow-hidden">
              <img 
                src="https://picsum.photos/seed/detail/400/500" 
                alt="Detail"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <span className="text-luxury-gold uppercase tracking-[0.3em] text-[10px] font-bold block">Our Heritage</span>
            <h2 className="text-4xl md:text-6xl font-serif leading-tight">The Art of Luvérin Jewels</h2>
            <p className="text-luxury-blue/70 text-lg leading-relaxed font-light">
              Luvérin Jewels is a modern luxury jewelry house from Pakistan, dedicated to the art of fine craftsmanship. Each piece is a testament to our commitment to elegance, quality, and the timeless beauty of authentic materials.
            </p>
            <p className="text-luxury-blue/70 text-lg leading-relaxed font-light">
              Our artisans blend traditional techniques with contemporary design to create jewelry that doesn't just adorn, but tells a story of sophistication and grace.
            </p>
            <button 
              onClick={() => setPage('about')}
              className="px-10 py-5 bg-luxury-blue text-white uppercase tracking-widest text-xs font-bold hover:bg-luxury-gold transition-colors"
            >
              Our Story
            </button>
          </motion.div>
        </div>
      </section>

      <ArtisanalHeritage />

      {/* Luxury Experience */}
      <section className="py-24 bg-luxury-blue text-white px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {[
            { icon: <ShieldCheck size={32} />, title: 'Premium Craftsmanship', desc: 'Every piece is meticulously handcrafted by master artisans.' },
            { icon: <Star size={32} />, title: 'Authentic Materials', desc: 'We use only the finest ethically sourced gold, diamonds, and gems.' },
            { icon: <Gift size={32} />, title: 'Luxury Packaging', desc: 'Your purchase arrives in our signature elegant gift packaging.' },
            { icon: <Truck size={32} />, title: 'Secure Shopping', desc: 'Enjoy fully insured and secure worldwide shipping.' }
          ].map((item, i) => (
            <div key={i} className="text-center space-y-4">
              <div className="text-luxury-gold flex justify-center mb-6">{item.icon}</div>
              <h3 className="text-xl font-serif">{item.title}</h3>
              <p className="text-white/60 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-32 px-6 bg-champagne/20">
        <div className="max-w-4xl mx-auto text-center">
          <span className="text-luxury-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-8 block">Client Experiences</span>
          <div className="relative">
            <motion.div 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              className="space-y-8"
            >
              <p className="text-2xl md:text-3xl font-serif italic leading-relaxed text-luxury-blue/80">
                "The craftsmanship of my wedding set from Luvérin is absolutely breathtaking. It's more than jewelry; it's a family heirloom that I will cherish forever."
              </p>
              <div>
                <h4 className="font-bold uppercase tracking-widest text-xs mb-1">Zoya Khan</h4>
                <p className="text-luxury-gold text-[10px] uppercase tracking-widest">Verified Collector</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Instagram Gallery */}
      <section className="py-24">
        <div className="text-center mb-16 px-6">
          <h2 className="text-4xl font-serif mb-4">Follow the Luvérin Journey</h2>
          <p className="text-luxury-blue/60 uppercase tracking-widest text-[10px] font-bold">@luverinjewels</p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6">
          {[
            '1602810318383-e386cc2a3ccf',
            '1603561591411-071c4f71a21a',
            '1588444839799-eb6bd27e386a',
            '1573408302185-91275f96399c',
            '1512163143273-bde0e3cc7410',
            '1506630448388-4e683c67ddb0'
          ].map((id, i) => (
            <div key={i} className="aspect-square overflow-hidden relative group">
              <img 
                src={`https://picsum.photos/seed/insta-${i}/600/600`} 
                alt="Instagram" 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-luxury-blue/40 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center">
                <Instagram className="text-white" size={24} />
              </div>
            </div>
          ))}
        </div>
      </section>

      <BespokeCreations />

      {/* Newsletter */}
      <section className="py-32 px-6 bg-deep-navy text-white text-center">
        <div className="max-w-2xl mx-auto space-y-8">
          <h2 className="text-4xl md:text-5xl font-serif">Join the Luvérin Circle</h2>
          <p className="text-white/60 font-light leading-relaxed">
            Subscribe to receive updates on new collections, exclusive launches, and private offers reserved for our inner circle.
          </p>
          <form className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 max-w-lg mx-auto">
            <input 
              type="email" 
              placeholder="Your Email Address" 
              className="flex-1 bg-transparent border-b border-white/20 py-4 px-2 focus:border-luxury-gold outline-none transition-colors text-sm"
            />
            <button className="bg-luxury-gold text-white px-8 py-4 uppercase tracking-widest text-[10px] font-bold hover:bg-white hover:text-luxury-blue transition-colors">
              Subscribe
            </button>
          </form>
        </div>
      </section>
    </div>
  );
};

const ShopPage = ({ setPage, setSelectedProduct, addToCart }: { setPage: (p: Page) => void, setSelectedProduct: (p: Product) => void, addToCart: (p: Product) => void }) => {
  const [filter, setFilter] = useState('All');
  
  const filteredProducts = filter === 'All' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === filter);

  return (
    <div className="pt-0 pb-24">
      <PageBanner 
        title="The Collection" 
        subtitle="Explore our complete range of handcrafted jewelry, from statement necklaces to delicate everyday essentials."
        image="https://picsum.photos/seed/collection/1920/1080"
      />
      <div className="max-w-7xl mx-auto px-6 mt-20">
        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-4 mb-16">
          {['All', 'Rings', 'Necklaces', 'Earrings', 'Bracelets'].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-8 py-3 text-[10px] uppercase tracking-widest font-bold transition-all duration-300 border ${
                filter === cat ? 'bg-luxury-blue text-white border-luxury-blue' : 'bg-transparent text-luxury-blue border-luxury-blue/10 hover:border-luxury-gold'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-8 gap-y-16">
          {filteredProducts.map((product) => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onClick={() => {
                setSelectedProduct(product);
                setPage('product');
              }}
              onAddToCart={(e) => {
                e.stopPropagation();
                addToCart(product);
              }}
            />
          ))}
        </div>
      </div>
      <SignatureExperience />
      <BespokeCreations />
    </div>
  );
};

const ProductPage = ({ product, addToCart }: { product: Product, addToCart: (p: Product) => void }) => {
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('details');

  if (!product) return null;

  return (
    <div className="pt-0 pb-24">
      <PageBanner 
        title={product.name} 
        subtitle={`Exquisite ${product.category} from our Signature Collection`}
        image="https://picsum.photos/seed/product-detail/1920/1080"
      />
      
      <div className="max-w-7xl mx-auto px-6 mt-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-24">
          {/* Gallery */}
          <div className="space-y-4">
            <div className="aspect-[4/5] bg-champagne overflow-hidden">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="aspect-square bg-champagne overflow-hidden cursor-pointer opacity-60 hover:opacity-100 transition-opacity">
                  <img 
                    src={product.image} 
                    alt="Thumbnail" 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Info */}
          <div className="space-y-8">
            <div>
              <span className="text-luxury-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-4 block">{product.category}</span>
              <h1 className="text-4xl md:text-5xl font-serif mb-4">{product.name}</h1>
              <p className="text-2xl text-luxury-blue/80">Rs. {product.price.toLocaleString()}</p>
            </div>

            <p className="text-luxury-blue/70 leading-relaxed font-light text-lg">
              {product.description}
            </p>

            <div className="space-y-4">
              <p className="text-[10px] uppercase tracking-widest font-bold">Materials</p>
              <div className="flex flex-wrap gap-2">
                {product.materials.map((m, i) => (
                  <span key={i} className="px-4 py-2 bg-champagne text-luxury-blue text-[10px] uppercase tracking-widest font-medium">
                    {m}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center space-x-6 pt-4">
              <div className="flex items-center border border-luxury-blue/10">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-4 hover:text-luxury-gold transition-colors"
                >
                  <Minus size={16} />
                </button>
                <span className="w-12 text-center font-medium">{quantity}</span>
                <button 
                  onClick={() => setQuantity(quantity + 1)}
                  className="p-4 hover:text-luxury-gold transition-colors"
                >
                  <Plus size={16} />
                </button>
              </div>
              <button 
                onClick={() => addToCart(product)}
                className="flex-1 bg-luxury-blue text-white py-4 uppercase tracking-widest text-xs font-bold hover:bg-luxury-gold transition-colors"
              >
                Add to Cart
              </button>
            </div>

            <button className="w-full border border-luxury-blue text-luxury-blue py-4 uppercase tracking-widest text-xs font-bold hover:bg-luxury-blue hover:text-white transition-all duration-500">
              Buy It Now
            </button>

            {/* Trust Elements */}
            <div className="grid grid-cols-2 gap-6 pt-8 border-t border-luxury-blue/10">
              <div className="flex items-center space-x-3">
                <ShieldCheck className="text-luxury-gold" size={20} />
                <span className="text-[10px] uppercase tracking-widest font-bold">Authenticity Guaranteed</span>
              </div>
              <div className="flex items-center space-x-3">
                <Truck className="text-luxury-gold" size={20} />
                <span className="text-[10px] uppercase tracking-widest font-bold">Secure Worldwide Shipping</span>
              </div>
              <div className="flex items-center space-x-3">
                <Gift className="text-luxury-gold" size={20} />
                <span className="text-[10px] uppercase tracking-widest font-bold">Premium Gift Packaging</span>
              </div>
              <div className="flex items-center space-x-3">
                <RotateCcw className="text-luxury-gold" size={20} />
                <span className="text-[10px] uppercase tracking-widest font-bold">14-Day Easy Returns</span>
              </div>
            </div>
          </div>
        </div>

        <ProductPromise />

        {/* Tabs */}
        <div className="border-t border-luxury-blue/10 pt-16 mb-24">
          <div className="flex justify-center space-x-12 mb-12">
            {['details', 'care', 'shipping'].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`text-[10px] uppercase tracking-[0.3em] font-bold pb-2 border-b-2 transition-all ${
                  activeTab === tab ? 'border-luxury-gold text-luxury-blue' : 'border-transparent text-luxury-blue/40'
                }`}
              >
                {tab === 'details' ? 'Product Details' : tab === 'care' ? 'Jewelry Care' : 'Shipping & Returns'}
              </button>
            ))}
          </div>
          
          <div className="max-w-3xl mx-auto text-center text-luxury-blue/70 leading-relaxed font-light">
            {activeTab === 'details' && (
              <div className="space-y-4">
                <p>Meticulously handcrafted in our Lahore studio, this piece represents the pinnacle of luxury jewelry design. Each stone is hand-selected for its brilliance and clarity, ensuring a masterpiece that lasts generations.</p>
                <ul className="text-sm space-y-2 pt-4">
                  <li>• Material: High-grade 18k Gold</li>
                  <li>• Weight: Approximately 4.5g</li>
                  <li>• Stones: Ethically sourced brilliant-cut diamonds</li>
                  <li>• Finish: High-polish mirror finish</li>
                </ul>
              </div>
            )}
            {activeTab === 'care' && (
              <p>To maintain the brilliance of your Luvérin piece, we recommend avoiding contact with perfumes, lotions, and harsh chemicals. Clean gently with a soft, lint-free cloth and store in your provided luxury pouch when not in use.</p>
            )}
            {activeTab === 'shipping' && (
              <p>We offer complimentary secure shipping across Pakistan. International orders are handled via premium couriers with full insurance. Returns are accepted within 14 days of delivery for unworn items in original packaging.</p>
            )}
          </div>
        </div>
        
        <StylingGuide />
      </div>
      <SignatureExperience />
      <BespokeCreations />
    </div>
  );
};

const AboutPage = () => {
  return (
    <div className="pt-0 pb-24">
      <PageBanner 
        title="Our Heritage" 
        subtitle="The story of Luvérin Jewels is a journey of passion, craftsmanship, and the pursuit of timeless elegance."
        image="https://picsum.photos/seed/heritage/1920/1080"
      />
      <div className="max-w-7xl mx-auto px-6 mt-20">
        <div className="text-center mb-24">
          <span className="text-luxury-gold uppercase tracking-[0.3em] text-[10px] font-bold mb-4 block">Our Story</span>
          <h1 className="text-5xl md:text-7xl font-serif mb-8">The Heritage of Luvérin</h1>
          <div className="w-24 h-[1px] bg-luxury-gold mx-auto mb-12" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center mb-32">
          <div className="space-y-8">
            <h2 className="text-4xl font-serif">A Vision of Elegance</h2>
            <p className="text-luxury-blue/70 text-lg leading-relaxed font-light">
              Founded with a passion for the extraordinary, Luvérin Jewels emerged as a beacon of luxury in the heart of Pakistan. Our journey began with a simple yet profound vision: to create jewelry that transcends time and trends.
            </p>
            <p className="text-luxury-blue/70 text-lg leading-relaxed font-light">
              We believe that every piece of jewelry is a milestone, a memory, and a masterpiece. This philosophy guides every sketch, every selection of stone, and every stroke of the artisan's hammer.
            </p>
          </div>
          <div className="aspect-[4/3] overflow-hidden">
            <img 
              src="https://picsum.photos/seed/jewelry-studio/800/600" 
              alt="Studio" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-32">
          {[
            { title: 'Exquisite Craftsmanship', desc: 'Our master artisans possess decades of experience, blending traditional techniques with modern precision.' },
            { title: 'Ethical Sourcing', desc: 'We are committed to the highest standards of ethical sourcing for all our diamonds and gemstones.' },
            { title: 'Timeless Design', desc: 'Our designs are created to be as relevant tomorrow as they are today, celebrating enduring beauty.' }
          ].map((item, i) => (
            <div key={i} className="text-center space-y-4 p-8 bg-champagne/20">
              <h3 className="text-2xl font-serif">{item.title}</h3>
              <p className="text-luxury-blue/60 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>

        <div className="bg-luxury-blue text-white p-16 md:p-24 text-center">
          <h2 className="text-4xl md:text-5xl font-serif mb-8">The Luvérin Philosophy</h2>
          <p className="text-white/60 text-xl max-w-3xl mx-auto font-light italic leading-relaxed">
            "We don't just make jewelry; we craft the artifacts of your most precious moments. Every Luvérin piece is a promise of quality, a celebration of beauty, and a legacy of luxury."
          </p>
        </div>
      </div>
      <SignatureExperience />
      <BespokeCreations />
    </div>
  );
};

const ContactPage = () => {
  return (
    <div className="pt-0 pb-24">
      <PageBanner 
        title="Contact Us" 
        subtitle="Our dedicated team is here to assist you with bespoke requests, product inquiries, or styling advice."
        image="https://picsum.photos/seed/concierge/1920/1080"
      />
      <div className="max-w-7xl mx-auto px-6 mt-20">
        <div className="text-center mb-24">
          <h1 className="text-5xl md:text-6xl font-serif mb-6">Contact the Concierge</h1>
          <p className="text-luxury-blue/60 max-w-2xl mx-auto font-light">
            Our dedicated team is here to assist you with bespoke requests, product inquiries, or styling advice.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Form */}
          <div className="space-y-12">
            <h2 className="text-3xl font-serif">Send a Message</h2>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest font-bold">Name</label>
                  <input type="text" className="w-full bg-transparent border-b border-luxury-blue/20 py-3 focus:border-luxury-gold outline-none transition-colors" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest font-bold">Email</label>
                  <input type="email" className="w-full bg-transparent border-b border-luxury-blue/20 py-3 focus:border-luxury-gold outline-none transition-colors" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest font-bold">Subject</label>
                <input type="text" className="w-full bg-transparent border-b border-luxury-blue/20 py-3 focus:border-luxury-gold outline-none transition-colors" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest font-bold">Message</label>
                <textarea rows={4} className="w-full bg-transparent border-b border-luxury-blue/20 py-3 focus:border-luxury-gold outline-none transition-colors resize-none"></textarea>
              </div>
              <button className="bg-luxury-blue text-white px-12 py-5 uppercase tracking-widest text-xs font-bold hover:bg-luxury-gold transition-colors">
                Send Message
              </button>
            </form>
          </div>

          {/* Info */}
          <div className="space-y-16">
            <div className="space-y-8">
              <h2 className="text-3xl font-serif">Visit Our Studio</h2>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <MapPin className="text-luxury-gold mt-1" size={20} />
                  <div>
                    <h4 className="font-bold uppercase tracking-widest text-xs mb-1">Address</h4>
                    <p className="text-luxury-blue/60 font-light">Gulberg III, Main Boulevard, Lahore, Pakistan</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Phone className="text-luxury-gold mt-1" size={20} />
                  <div>
                    <h4 className="font-bold uppercase tracking-widest text-xs mb-1">WhatsApp & Phone</h4>
                    <p className="text-luxury-blue/60 font-light">+92 300 1234567</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <Mail className="text-luxury-gold mt-1" size={20} />
                  <div>
                    <h4 className="font-bold uppercase tracking-widest text-xs mb-1">Email</h4>
                    <p className="text-luxury-blue/60 font-light">concierge@luverin.pk</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Map Placeholder */}
            <div className="aspect-video bg-champagne flex items-center justify-center relative overflow-hidden">
              <img 
                src="https://picsum.photos/seed/map/800/450" 
                alt="Map" 
                className="w-full h-full object-cover opacity-50"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-white p-4 shadow-2xl">
                  <MapPin className="text-luxury-gold" size={32} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <SignatureExperience />
      <BespokeCreations />
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cartCount, setCartCount] = useState(0);

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [page]);

  const addToCart = (p: Product) => {
    setCartCount(prev => prev + 1);
    // In a real app, we'd add to a cart state
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar currentPage={page} setPage={setPage} cartCount={cartCount} />
      
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={page + (selectedProduct?.id || '')}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {page === 'home' && (
              <HomePage 
                setPage={setPage} 
                setSelectedProduct={setSelectedProduct} 
                addToCart={addToCart} 
              />
            )}
            {page === 'shop' && (
              <ShopPage 
                setPage={setPage} 
                setSelectedProduct={setSelectedProduct} 
                addToCart={addToCart} 
              />
            )}
            {page === 'product' && selectedProduct && (
              <ProductPage 
                product={selectedProduct} 
                addToCart={addToCart} 
              />
            )}
            {page === 'about' && <AboutPage />}
            {page === 'contact' && <ContactPage />}
          </motion.div>
        </AnimatePresence>
      </main>

      <Footer setPage={setPage} />

      {/* Sticky Add to Cart for Product Page */}
      {page === 'product' && selectedProduct && (
        <motion.div 
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="fixed bottom-0 left-0 w-full bg-white border-t border-luxury-blue/10 p-4 z-40 lg:hidden flex items-center justify-between"
        >
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-widest font-bold text-luxury-blue/60">{selectedProduct.name}</span>
            <span className="font-serif font-bold">Rs. {selectedProduct.price.toLocaleString()}</span>
          </div>
          <button 
            onClick={() => addToCart(selectedProduct)}
            className="bg-luxury-blue text-white px-8 py-3 uppercase tracking-widest text-[10px] font-bold hover:bg-luxury-gold transition-colors"
          >
            Add to Cart
          </button>
        </motion.div>
      )}
    </div>
  );
}
